g++ -std=c++11 -g -o app -Wall *.cpp
